const path = require("path");
const fs = require("fs");
const sharp = require("sharp");
const AWS = require("aws-sdk");
const shortid = require("shortid");
const { pipeline } = require("stream");
const { promisify } = require("util");
const {
  S3Client,
  PutObjectCommand,
  DeleteObjectCommand,
} = require("@aws-sdk/client-s3");
const { DynamoDBClient, PutItemCommand } = require("@aws-sdk/client-dynamodb");

const dotenv = require("dotenv");
const s3 = new S3Client({ region: process.env.AWS_REGION });
const dynamoDB = new DynamoDBClient({ region: process.env.AWS_REGION });
const BUCKET_NAME = process.env.S3_BUCKET_NAME;
const tableName = process.env.DYNAMODB_TABLE_NAME;
dotenv.config();

console.log("AWS_ACCESS_KEY_ID:", process.env.AWS_ACCESS_KEY_ID);
console.log("AWS_SECRET_ACCESS_KEY:", process.env.AWS_SECRET_ACCESS_KEY);
console.log("AWS_REGION:", process.env.AWS_REGION);
console.log("S3_BUCKET_NAME:", process.env.S3_BUCKET_NAME);
console.log("DYNAMODB_TABLE_NAME:", process.env.DYNAMODB_TABLE_NAME);

module.exports = () => {
  const uploadImage = async (req, res) => {
    // Check if username is provided in the request body
    if (!req.body.username) {
      return res.status(400).json({ message: "Username is required" });
    }

    if (!req.files || !req.files.files) {
      return res.status(400).json({ message: "No files were uploaded" });
    }

    const files = Array.isArray(req.files.files)
      ? req.files.files
      : [req.files.files];
    const uploadPromises = files.map(async (file) => {
      const fileKey = `uploads/${shortid.generate()}-${file.name}`;

      try {
        // Upload to S3
        const uploadParams = {
          Bucket: BUCKET_NAME,
          Key: fileKey,
          Body: file.data,
        };
        await s3.send(new PutObjectCommand(uploadParams));

        // Store metadata in DynamoDB
        const metadata = {
          "qut-username": { S: req.body.username }, // Ensure this is provided in the request
          "image-id": { S: shortid.generate() },
          "file-name": { S: file.name },
          "file-key": { S: fileKey },
          "upload-date": { S: new Date().toISOString() },
        };

        const dbParams = {
          TableName: tableName,
          Item: metadata,
        };

        console.log("Storing metadata in DynamoDB:", dbParams);
        await dynamoDB.send(new PutItemCommand(dbParams));

        return { id: metadata["image-id"].S, key: fileKey, name: file.name };
      } catch (err) {
        console.error(
          "Error uploading file to S3 or storing metadata in DynamoDB:",
          err
        );
        throw { message: "File Upload Failed", error: err };
      }
    });

    try {
      const uploadedFiles = await Promise.all(uploadPromises);
      res
        .status(200)
        .json({ message: "Files uploaded successfully", files: uploadedFiles });
    } catch (error) {
      console.error("Error in uploadImage:", error);
      res.status(500).json({ message: "File upload failed", error });
    }
  };

  const convertImage = async (req, res) => {
    const { file } = req.files;
    const { format } = req.body;

    if (!file || !format) {
      return res.status(400).json({ message: "File and format are required" });
    }

    const validFormats = ["jpeg", "png", "webp"];
    if (!validFormats.includes(format)) {
      return res.status(400).json({ message: "Invalid format selected" });
    }

    try {
      const buffer = await sharp(file.data).toFormat(format).toBuffer();
      const fileName = `${shortid.generate()}.${format}`;
      const params = {
        Bucket: BUCKET_NAME,
        Key: fileName,
        Body: buffer,
        ContentType: `image/${format}`,
      };

      await s3.send(new PutObjectCommand(params));

      res
        .status(200)
        .json({
          message: "Image converted and uploaded successfully",
          fileName,
        });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Error converting and uploading image" });
    }
  };

  const listUploadedFiles = (req, res) => {
    const outputDir = path.join(__dirname, "..", "uploads");

    fs.readdir(outputDir, (err, files) => {
      if (err) {
        return res
          .status(500)
          .json({ message: "Unable to list files", error: err });
      }

      res.status(200).json({ files });
    });
  };

  const deleteImage = async (req, res) => {
    const { filename } = req.params;
    const uploadPath = path.join(__dirname, "..", "uploads", filename);
    const outputPath = path.join(__dirname, "..", "output", filename);

    try {
      if (fs.existsSync(uploadPath)) {
        fs.unlinkSync(uploadPath);
        updateMetadata(UPLOADS_METADATA_PATH, filename);
      }
      if (fs.existsSync(outputPath)) {
        fs.unlinkSync(outputPath);
        updateMetadata(OUTPUT_METADATA_PATH, filename);
      }
      res.status(200).json({ message: "File deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "File deletion failed", error });
    }
  };

  return { uploadImage, convertImage, listUploadedFiles, deleteImage };
};
